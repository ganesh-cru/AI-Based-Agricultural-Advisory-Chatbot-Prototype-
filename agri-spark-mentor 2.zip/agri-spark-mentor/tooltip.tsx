export function TooltipProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
