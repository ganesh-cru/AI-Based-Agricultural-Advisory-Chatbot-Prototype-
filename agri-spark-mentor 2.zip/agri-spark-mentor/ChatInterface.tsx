export function ChatInterface() {
  return (
    <div className="border rounded-xl p-6 bg-white shadow-md">
      <h3 className="font-semibold text-lg text-green-700 mb-3">Chat with Agri-Spark AI</h3>
      <p className="text-gray-600">[Chat system coming soon]</p>
    </div>
  )
}
