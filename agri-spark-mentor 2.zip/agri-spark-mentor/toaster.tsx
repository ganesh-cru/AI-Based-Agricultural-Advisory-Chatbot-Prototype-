export function Toaster() {
  return null // placeholder – safe to remove later
}
